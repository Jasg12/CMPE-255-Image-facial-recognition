# FaceEmotionClassifeir_LogisticRegression

Objective:
Implement a Logistic Regression model to classify images based on expressions made by human beings through images.

Dataset:
Dataset collected from : http://cvit.iiit.ac.in/projects/IMFDB/

General Information:
Code executed in Google Colab
Total number of images considered: 11500 (approx)
Total number of images in the training data set: 8000 (approx)
Total number of images in the validation data set: 3000 (approx)
