# Face_Emotion_Classifier_WithoutTL
Objective:
To create a neural network capable of detecting expressions of human beings from an image.

Dataset:
Data taken from http://cvit.iiit.ac.in/projects/IMFDB/

General Information:
* Code executed in Google Colab
* Total number of images considered: 11500 (approx)
* Total number of images in the training data set: 8000 (approx)
* Total number of images in the validation data set: 3000 (approx)
